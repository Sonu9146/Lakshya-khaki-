# Lakshya Khaki Android Project

This project wraps the supplied HTML app in an Android WebView.

## Build
Open this folder in Android Studio and choose **Build > Build APK(s)**.
The debug APK will be under:
`app/build/outputs/apk/debug/app-debug.apk`

The launcher opens `lakshya-khaki-app.html`.
